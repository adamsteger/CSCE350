# CSCE350
# Floyd's
To compile/run Floyd's algorithm code, use the following instructions:
    make floyd
    ./floyd input.txt

To clear executable/output file, use the following instruction:
    make clean
